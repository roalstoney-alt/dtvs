DTVS Windows Real Video Pilot Handoff v0.2.0-pilot

This is a pilot handoff, not a formal Worker release or installer.
real_render_executor=ncnn_vulkan; formal_release=false; installer=false.
Real-ESRGAN executables, models, source video, secrets, and Windows results are not bundled.
Run VERIFY_INPUTS.cmd first. Run 10 seconds before the one-minute pilot.
The Mac environment must not be used to claim Windows PASS.
