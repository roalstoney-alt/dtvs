DTVS Worker Pack v0.1.0

Public commands:
  .\dtvs-worker.ps1 doctor
  .\dtvs-worker.ps1 run --package <task-package.zip> --workspace D:\DTVS
  .\dtvs-worker.ps1 export --workspace D:\DTVS --run-id <run_id> --destination <drive>
  .\dtvs-worker.ps1 submit --workspace D:\DTVS --run-id <run_id> --assignment <assignment.json>

FFmpeg, restoration models, NVIDIA drivers, Python, and licensed media are not bundled.
No RTX 4060 render result is included in this package.
